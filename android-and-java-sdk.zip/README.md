AppWarp_JAVA_SDK
==============


1. [Register] (https://apphq.shephertz.com/register) with AppWarp platform.
2. Create an app once you are on Quick start page after registration.
3. If you are already registered, login to [AppHQ] (http://apphq.shephertz.com/) console and create an app from App Manager Tab.

__Download and Set up SDK :-__

1). [Download] (http://appwarp.shephertz.com/wp-content/themes/twentytwelve/download/android-and-java-sdk.zip) Java SDK

2). Unzip downloaded Zip file.

3). Folder will contain App42MultiPlayerGamingSDK-x.x.x.jar,other required jar file in lib folder and docs.

4). If you are making new project then add App42MultiPlayerGamingSDK-x.x.x.jar and other required jar file in lib folder.

 or 
 
4). If your using your existing project then add App42MultiPlayerGamingSDK-x.x.x.jar and lib jars in your project lib folder.
 
5).Put these jar files in class path of your Java project.

6). API USAGE GUIDE (http://appwarp.shephertz.com/game-development-center/java-game-developers-home/java-usage-guide/)

